# cmdvninja-sublime

Sublime Text Plug-in which uses the CmdV Ninja application's api to access code snippets with ease.
